//
//  ViewController.swift
//  MVVMClean
//
//  Created by Mac mini on 09/07/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue
    }


}

