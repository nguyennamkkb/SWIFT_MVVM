//
//  PostMainViewController.swift
//  MVVMClean
//
//  Created by Mac mini on 12/07/2024.
//

import UIKit

class PostMainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .brown
        // Do any additional setup after loading the view.
    }
}
