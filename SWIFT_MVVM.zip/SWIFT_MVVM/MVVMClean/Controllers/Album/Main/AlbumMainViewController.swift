//
//  AlbumMainViewController.swift
//  MVVMClean
//
//  Created by Mac mini on 12/07/2024.
//

import UIKit

class AlbumMainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .green
    }
    
}
